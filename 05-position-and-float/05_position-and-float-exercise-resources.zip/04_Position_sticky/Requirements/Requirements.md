# 04 - Position Sticky
------
## Constraints 
* Create a container with class **container**
    * Create a paragraph with class **sticky**. Try to fix the paragraph using **position:sticky**. Style the container.
    * Create several containers with content inside them 