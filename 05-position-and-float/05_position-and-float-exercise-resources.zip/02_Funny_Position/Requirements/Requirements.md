# 02 - Funny Position
------
## Constraints 
 * Use semantic tags 
 * Create a div with class "container"
    * Create 5 yellow containers inside. Try to position them in the corners and in the center with **position:absolute**
        * Create 5 red containers in the yellow containers. Position then in the center.