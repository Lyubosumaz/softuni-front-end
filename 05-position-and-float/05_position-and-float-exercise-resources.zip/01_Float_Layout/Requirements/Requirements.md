# 01 - Float Layout
------
## Constraints
 * Change the document **title** to *FLoat Layout*
 * Use semantic tags 
 * Try to make the layout using the float property
